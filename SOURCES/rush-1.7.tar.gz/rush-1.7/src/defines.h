#define CANONICAL_PROGRAM_NAME "/usr/local/sbin/rush"
#define SYSCONFDIR "/usr/local/etc"
#define LOCALSTATEDIR "/usr/local/var"
